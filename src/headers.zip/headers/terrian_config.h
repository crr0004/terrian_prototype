#define SHADERS_DIR C:/Users/crhodes/dev/projects/terrian_prototype/shaders
#define SCRIPTS_DIR C:/Users/crhodes/dev/projects/terrian_prototype/lua_scripts
