#ifndef GEOMETRYPOINT_H
#define GEOMETRYPOINT_H
namespace Geometry{

class Point{
	public:
		Point(float x, float y, float z);
		~Point();
};

}

#endif
